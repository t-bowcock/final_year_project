from django.apps import AppConfig


class QueryappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "QueryApp"
